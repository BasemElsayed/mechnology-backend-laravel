<br>
<span>Name:  </span>
<p>{{$userName}}</p>

<br>
<span>Commerical Register:  </span>
<p>{{$commerical}}</p>


<br>
<span>Phone:  </span>
<p>{{$phoneNumber}}</p>


<br>
<span>Email:  </span>
<p>{{$userEmail}}</p>



<br>
<span>Message:  </span>
<p>{{$Message}}</p>






