<?php

return array(
    "driver" => "smtp",
    "host" => "smtp.mailtrap.io",
    "port" => 2525,
    "from" => array(
        "address" => "from@example.com",
        "name" => "Example"
    ),
    "username" => "97c46cc7eab655",
    "password" => "e3a0bbd0f7ffe2",
    "sendmail" => "/usr/sbin/sendmail -bs",
    "pretend" => false
  );