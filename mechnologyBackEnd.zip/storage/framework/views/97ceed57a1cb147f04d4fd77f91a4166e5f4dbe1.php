<br>
<span>Name:  </span>
<p><?php echo e($userName); ?></p>

<br>
<span>Phone:  </span>
<p><?php echo e($phoneNumber); ?></p>


<br>
<span>Email:  </span>
<p><?php echo e($userEmail); ?></p>



<br>
<span>Message:  </span>
<p><?php echo e($Message); ?></p>
